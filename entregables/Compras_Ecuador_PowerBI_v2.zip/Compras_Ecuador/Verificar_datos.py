import json,collections,datetime,os,textwrap
from pathlib import Path
from decimal import Decimal as D
R=Path(__file__).resolve().parent;raw=json.loads((R/'Fuentes/BASE KPIS.json').read_text());p=[r for r in raw if r['Fecha'] or r['Etiquetas de fila']];a=json.loads((R/'Fuentes/AHORROS.json').read_text())
num=lambda x:D(str(x or 0));total=lambda rs,k:sum((num(r[k]) for r in rs),D(0))
checks=[]
def check(n,actual,expected):
 assert actual==expected,(n,actual,expected);checks.append(f'OK | {n}: {actual}')
check('Filas detalle',len(p),359);check('Filas control excluidas',len(raw)-len(p),3)
for label,val in [('Total Compras','53587.78'),('Total Servicios','302592.08')]:check(label,total([r for r in p if r['TIPO SERVICIO']==label],'Suma de importe'),D(val))
check('Total',total(p,'Suma de importe'),D('356179.86'));check('Suma FACTURAS',total(p,'FACTURAS'),D(358))
check('Quito',total(p,'Quito'),D('165774.87'));check('Guayaquil',total(p,'Guayaquil'),D('190404.99'))
check('Filas descuadradas ciudad',sum(abs(num(r['Suma de importe'])-num(r['Quito'])-num(r['Guayaquil']))>D('.005') for r in p),0)
check('Ahorro',total(a,'COTI 1')-total(a,'COTI 2'),D('15980.72'))
check('Ahorros diferencias individuales',sum(abs(num(r['COTI 1'])-num(r['COTI 2'])-(D(0) if r['DIFERENCIA']=='$ -' else num(r['DIFERENCIA'])))>D('.005') for r in a),0)
check('Credito',total([r for r in p if r['F PAGO']=='CR'],'Suma de importe'),D('349688.26'))
check('Contado',total([r for r in p if r['F PAGO']=='CONTADO'],'Suma de importe'),D('6491.60'))
# Resolve all visual references against model metadata.
m=json.loads((R/'Compras.SemanticModel/model.bim').read_text())['model'];names={t['name']:{'Measure':{z['name'] for z in t.get('measures',[])},'Column':{z['name'] for z in t['columns']}} for t in m['tables']}
refs=0
for path in R.glob('Compras.Report/definition/pages/*/visuals/*/visual.json'):
 d=json.loads(path.read_text())
 for v in d['visual'].get('query',{}).get('queryState',{}).values():
  for pr in v['projections']:
   kind,field=next(iter(pr['field'].items()));assert field['Property'] in names[field['Expression']['SourceRef']['Entity']][kind];refs+=1
checks.append(f'OK | Referencias visuales a campos/medidas existentes: {refs}')
(R/'Validacion_datos.txt').write_text('\n'.join(checks)+'\n\nValidacion independiente en Python/Decimal. No se ejecuto motor M, DAX ni Power BI Desktop.\n')

print("Conciliaciones y referencias correctas. Ver Validacion_datos.txt")
